const mockjs = require('mockjs');

const result = [
  {
    name: '刘立东',
    sex: '男',
    age: '24',
    email: 'lidong.liu@hand-china.com',
    birth: '1996-11-07',
    techStack: ['H5', 'React', 'Vue'],
  },
  {
    name: '廖莉娜',
    sex: '女',
    age: '23',
    email: 'lina.liao@hand-china.com',
    birth: '1997-06-05',
    techStack: ['H5', 'React', 'Vue'],
  },
];

const addUser = req => {
  result.push(req);
  return { code: 0 };
};
const queryUser = (req, res) => {
  const size = req.params.size || 10;
  const page = req.params.page || 0;
  const d = mockjs.mock({
    ' content|1-30': result,
    size,
    number: page,
    numberOfElements: (thisObj) => thisObj.context.root.content.length,
    totalElements: 34,
  });
  res.json(d);
};

export default {
  'GET /_api/query-intro-info': queryUser,
  'POST /_api/add-user': addUser,
};
